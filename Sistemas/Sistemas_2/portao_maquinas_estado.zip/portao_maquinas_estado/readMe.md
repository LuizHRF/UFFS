# Trabalho de Máquinas de Estado - Sistemas Digitais
*Luiz Faccio - 2211100003*
*Bianca Gabriela Fritsch - 1911100002*

Este .zip contém:

    - 1 pasta (Digital), que são os arquivos utilizados no Digital para simular o funcionamento do exercício;
    - 3 arquivos VHDL, utilizados na compilação do projeto na FPGA;
    - Relatório da atividade em PDF.

## Link alternativo para o vídeo:

[https://drive.google.com/file/d/1BTo-fhpXqmm1psMaTR-7jGJI5wboY2bs/view?usp=sharing]