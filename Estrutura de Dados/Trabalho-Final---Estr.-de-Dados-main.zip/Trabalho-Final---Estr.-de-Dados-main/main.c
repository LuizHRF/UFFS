#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

#define EXIT 10  // valor fixo para a opção que finaliza a aplicação

// Struct que representa um item de uma lista de compras armazenada em uma arvore binaria de busca
struct item {
	char produto[50];
	int quantidade;
     struct item  *esquerdo; 
     struct item  *direito;
};
typedef struct item Item;

// Apresenta o primeiro menu da aplicação e retorna a opção selecionada
int menu1()
{
     int op = 0;
     printf("\n\t[Menu principal]\n");
     printf("[1] - Gerenciar lista de compras A\n");
     printf("[2] - Gerenciar lista de compras B\n");
     printf("[3] - Verificar itens duplicados\n");
     printf("[%d] - Sair do programa",EXIT);
     printf("\nDigite a opcao: ");
     scanf("%d",&op);
     return op;
}

// Apresenta o segundo menu da aplicação e retorna a opção selecionada
int menu2()
{
    int op = 0;
    //printf("\t[Submenu - Gerenciar lista de compras]\n");
    
    printf("[1] - Inserir produto\n");
    printf("[2] - Pesquisar produto\n");
    printf("[3] - Atualizar quantidade de um produto\n");
    printf("[4] - Listar todos os produtos nesta lista\n");
    printf("[5] - Deletar um produto\n");
    printf("[%d] - Retornar para o menu principal",EXIT);
    printf("\nDigite a opcao: ");
    scanf("%d",&op); 
    return op;
}


// Cria um novo Item para ser adicionado às listas
Item* create()
{
    Item *new = malloc(sizeof(Item));
    char nome[50];
    
    printf("Digite o nome do produto: ");
    scanf("%s", nome);
    int quantidade;
    printf("Digite a quantidade disponível deste produto: ");
    scanf("%d", &quantidade);
    
    strcpy(new->produto, nome);
    new->quantidade = quantidade;
    new->direito = NULL;
    new->esquerdo = NULL;

    return new;
}

// Permite o cadastro de um item (caso o produto ainda não exista) em uma lista de compas
Item* insert(Item *raiz, Item *new)
{
     if(raiz == NULL)
     {
         return new;
     }
     else if(strcmp(raiz->produto, new->produto)==0)
     {
         printf("Inserção cancelada (produto já existente)");
         return raiz;
     }
     else if(strcmp(raiz->produto, new->produto)<0)
     {
         raiz->direito = insert(raiz->direito, new);
     }
     else
     {
         raiz->esquerdo = insert(raiz->esquerdo, new);
     }
     return raiz;
}

Item* query(Item *raiz, char prod[])
{
     if(raiz == NULL)
     {
        return NULL;
     }
     if(strcmp(raiz->produto, prod)==0)
     {
        return raiz;
     }
     
     if(strcmp(prod, raiz->produto)<0)
     {
        query(raiz->esquerdo, prod);    
     }
     else
     {
         query(raiz->direito, prod);
     }
}

// Permite a atualização da quantidade de um produto (caso exista) na lista de compras
void update(Item *raiz, char prod[])
{
    //Procurando produto na lista
     if(raiz==NULL)
     {
        printf("Produto inexistente!\n");
        return;
     }
     if(strcmp(raiz->produto, prod)==0)
     {
         printf("Qual a nova quantidade de %s?", raiz->produto);
         scanf("%d",&raiz->quantidade);
         printf("Quantidade atualizada com sucesso!");
     }
     else if(strcmp(prod, raiz->produto)<0)
     {
        update(raiz->esquerdo, prod);    
     }
     else
     {
         update(raiz->direito, prod);
     }
     return;
}

// Listar todos os itens da lista de compras em ordem alfabética;
void list(Item *raiz)
{
     if(raiz==NULL)
     {
         return;
     }
    
     list(raiz->esquerdo);
     printf("%d \t| %s\n", raiz->quantidade, raiz->produto);
     list(raiz->direito);
     return;
}

// Permite excluir um item de uma lista de compras
Item* delete(Item *raiz, char prod[]) {
     if (raiz == NULL) {
          printf("Produto não encontrado!\n");
          return NULL;
     }
     else {
          if (strcmp(raiz->produto, prod) == 0) {
               // remove as folhas
               if (raiz->esquerdo == NULL && raiz->direito == NULL) {
                    printf("\nProduto %s removido com sucesso!\n", raiz->produto);
                    free(raiz);
                    return NULL;
               }
               else {
                    // remove nos que tem apenas um filho
                    if (raiz->esquerdo == NULL || raiz->direito == NULL) {
                         Item *aux;
                         if (raiz->esquerdo != NULL) {
                              aux = raiz->esquerdo;
                         }
                         else {
                              aux= raiz->direito;
                         }
                         printf("\nProduto %s removido com sucesso!\n", raiz->produto);
                         free(raiz);
                         return aux;
                    }
                    else {
                         Item *aux = raiz->esquerdo;
                         while(aux->direito != NULL) {
                              aux = aux->direito;
                         }
                         strcpy(raiz->produto, aux->produto);
                         raiz->quantidade = aux->quantidade;
                         strcpy(aux->produto, prod);
                         raiz->esquerdo = delete(raiz->esquerdo, prod);
                         return raiz;
                    }
               }
          }
          else {
               if (strcmp(prod, raiz->produto) < 0) {
                    raiz->esquerdo = delete(raiz->esquerdo, prod);
               }
               else {
                    raiz->direito = delete(raiz->direito, prod);
               }
               return raiz;
          }
     }
}

void turnIntoLinear(Item *raiz){
     if (raiz == NULL || raiz->direito && raiz->esquerdo == NULL) {
          return;
     }
     if (raiz->esquerdo != NULL) 
     {
          turnIntoLinear(raiz->esquerdo);
          Item *auxDireito = raiz->direito;
          raiz->direito = raiz->esquerdo;
          raiz->esquerdo = NULL;
          Item *aux = raiz->direito;
          while (aux->direito != NULL) 
          {
            aux = aux->direito;
          }
          aux->direito = auxDireito;
     }
     turnIntoLinear(raiz->direito);
}

void printList(Item *listaA, Item *listaB){
     Item *auxA = NULL;
     Item *auxB = NULL;
     printf("Interseçao:\n");
     for (auxA = listaA; auxA != NULL; auxA = auxA->direito)
     {
          for (auxB = listaB; auxB != NULL; auxB = auxB->direito)
          {
               if (strcmp(auxA->produto, auxB->produto) == 0)
               {
                    printf("\n %s", auxB->produto);
               }
          }
     }
     printf("\n");
}

void intersect(Item* raizA, Item* raizB) {
     Item *listaA = raizA;
     Item *listaB = raizB;
     turnIntoLinear(listaA);
     turnIntoLinear(listaB);
     printList(listaA, listaB);
}


// Programa principal
int main()
{
    int opcao1;
    int opcao2;
    Item *raizA = NULL;
    Item *raizB = NULL;
    char temp[50];

    opcao1 = 0;
    while (opcao1 != EXIT)
    {
          opcao1 = menu1();
               
          switch(opcao1)
          {
               case 1 : // gerenciar lista de compras A
                    opcao2 = 0;
                    while(opcao2 != EXIT){
                         printf("\n\n\t[Lista de Compras A]\n");
                         opcao2 = menu2();
                         switch(opcao2){ // operacoes sobre a arvore A
                              case 1 : 
                                   raizA = insert(raizA, create());
                                   break;
                              case 2 :
                                    if (raizA == NULL) {
                                        printf("Lista vazia!\n");
                                        break;
                                    }
                                    printf("Digite o produto que gostaria de procurar: ");
                                    scanf("%s", temp);
                                    Item *queryReturn = query(raizA, temp);
                                    if (queryReturn == NULL) {
                                        printf("Produto não encontrado na lista!");
                                    }
                                    else {
                                        printf("O produto está na lista. Quantidade: %d", queryReturn->quantidade);
                                    }
                                    break;
                              case 3 :
                                    if (raizA == NULL) {
                                        printf("Lista vazia!\n");
                                        break;
                                    }
                                    printf("Digite o produto que gostaria de atualizar: ");
                                    scanf("%s", temp);
                                    update(raizA, temp);
                                    break;
                              case 4 : 
                                   if(raizA==NULL)
                                   {
                                       printf("Lista vazia\n");
                                   }
                                   else
                                   {
                                   printf("Qtd.\t| Produto:\n");
                                   list(raizA);
                                   }
                                   break;
                              case 5 :
                                    if (raizA == NULL) {
                                        printf("Lista vazia!\n");
                                        break;
                                    }
                                    printf("Digite o produto que gostaria de remover: ");
                                    scanf("%s", temp);
                                    raizA = delete(raizA, temp);
                         }    
                    }
                    break;
               case 2 :
                    opcao2 = 0;
                    while(opcao2 != EXIT){
                        printf("\n\n\t[Lista de Compras B]\n");
                        opcao2 = menu2();
                        switch(opcao2){ // operacoes sobre a arvore B
                              case 1 : 
                                   raizB = insert(raizB, create());
                                   break;
                              case 2 :
                                    if (raizB == NULL) {
                                        printf("Lista vazia!\n");
                                        break;
                                    }
                                    printf("Digite o produto que gostaria de procurar: ");
                                    scanf("%s", temp);
                                    int queryReturn = query(raizB, temp);
                                    if (queryReturn == 0) {
                                        printf("Produto não encontrado na lista!");
                                    }
                                    else {
                                        printf("O produto está na lista. Quantidade: %d", queryReturn);
                                    }
                                    break;
                              case 3 :
                                    if (raizB == NULL) {
                                        printf("Lista vazia!\n");
                                        break;
                                    }
                                    printf("Digite o produto que gostaria de atualizar: ");
                                    scanf("%s", temp);
                                    update(raizB, temp);
                                    break;
                              case 4 : 
                                   if(raizB == NULL)
                                   {
                                       printf("Lista vazia\n");
                                   }
                                   else
                                   {
                                   printf("Qtd.\t| Produto:\n");
                                   list(raizB);
                                   }
                                   break;
                              case 5 :
                                    if (raizB == NULL) {
                                        printf("Lista vazia!\n");
                                        break;
                                    }
                                    printf("Digite o produto que gostaria de remover: ");
                                    scanf("%s", temp);
                                    raizB = delete(raizB, temp);
                        }    
                    }
                    break;
               case 3 : // Visualizar itens duplicados
               intersect(raizA, raizB);
          }
    }
    return 0;
}
